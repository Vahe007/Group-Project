import StartingPage.CheckBoxPanel;

import javax.swing.*;
import java.awt.*;

public class solution {
    public static void main(String[] args) {

//        new GUI();
        JFrame frame = new JFrame("Equation Solver Program");
        frame.add(new CheckBoxPanel().panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

    }
}

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GeneralGUI implements ActionListener {
    protected JCheckBox quadratic;
    protected JCheckBox linear;
    protected JCheckBox factorial;
    private JLabel quadraticText;
    private JLabel linearText;
    private JLabel factorialText;
    protected JPanel panel;
    protected JButton select;
    private ButtonGroup checkBoxGroup;

    public GeneralGUI() {

        checkBoxGroup = new ButtonGroup();

        quadratic = new JCheckBox();
        linear = new JCheckBox();
        factorial = new JCheckBox();

        checkBoxGroup.add(quadratic);
        checkBoxGroup.add(linear);
        checkBoxGroup.add(factorial);

        quadraticText = new JLabel();
        linearText = new JLabel();
        factorialText = new JLabel();

        quadraticText.setText("Quadratic equation solver");
        linearText.setText("Quadratic equation solver");
        factorialText.setText("Quadratic equation solver");


        select = new JButton("Select");
        select.setText("SELECT");
//        select.setPreferredSize(new Dimension(50, 30));



        panel = new JPanel();
        panel.add(quadratic);
        panel.add(linear);
        panel.add(factorial);

    }

    public JPanel getPanel() {
        return this.panel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}

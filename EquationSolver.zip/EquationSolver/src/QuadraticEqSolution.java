public class QuadraticEqSolution {
    public double x1;
    public double x2;
    public double determinant;

    double a;
    double b;
    double c;

    public QuadraticEqSolution(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;

    }

    public boolean isValid(double d) {
        if (d < 0) {
            return false;
        }
        return true;
    }

    public double[] calculate() {


        determinant = b * b - 4 * a * c;

        if (determinant > 0) {

            x1 = (-b + Math.sqrt(determinant)) / (2 * a);
            x2 = (-b - Math.sqrt(determinant)) / (2 * a);

        }
        else if (determinant == 0) {
            x1 = x2 = -b / (2 * a);

        } else {
            return null;
        }

        double[] arr = {x1, x2};
        return arr;


    }


    public double getDeterminant() {
        return this.determinant;
    }
}


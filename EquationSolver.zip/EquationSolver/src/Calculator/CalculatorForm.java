package Calculator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculatorForm {
    private JPanel panel;
    private JTextField input;
    private JButton plus;
    private JButton minus;
    private JButton multiplication;
    private JButton division;
    private JButton a1Button;
    private JButton a2Button;
    private JButton a3Button;
    private JButton a4Button;
    private JButton a5Button;
    private JButton a6Button;
    private JButton a7Button;
    private JButton a8Button;
    private JButton a9Button;
    private JButton dot;
    private JButton a0Button;
    private JButton cButton;
    private JButton runButton;
    private JLabel errorLabel;


    public CalculatorForm() {
//        panel.setLayout(new GridLayout(5, 5));

        panel.setBorder(BorderFactory.createEmptyBorder(50, 170, 70, 170));
        Color bgColor = new Color(28, 28, 28);
        Color numColor = new Color(80, 80, 80);
        Color operatorColor = new Color(255, 149, 0);
        Color cColor = new Color(212, 212, 210);

        panel.setBackground(bgColor);

        plus.setBackground(operatorColor);
        minus.setBackground(operatorColor);
        multiplication.setBackground(operatorColor);
        division.setBackground(operatorColor);
        cButton.setBackground(cColor);
        runButton.setBackground(cColor);


        a0Button.setForeground(Color.WHITE);
        a1Button.setForeground(Color.WHITE);
        a2Button.setForeground(Color.WHITE);
        a3Button.setForeground(Color.WHITE);
        a4Button.setForeground(Color.WHITE);
        a5Button.setForeground(Color.WHITE);
        a6Button.setForeground(Color.WHITE);
        a7Button.setForeground(Color.WHITE);
        a8Button.setForeground(Color.WHITE);
        a9Button.setForeground(Color.WHITE);
        dot.setForeground(Color.WHITE);


        a0Button.setBackground(numColor);
        a1Button.setBackground(numColor);
        a2Button.setBackground(numColor);
        a3Button.setBackground(numColor);
        a4Button.setBackground(numColor);
        a5Button.setBackground(numColor);
        a6Button.setBackground(numColor);
        a7Button.setBackground(numColor);
        a8Button.setBackground(numColor);
        a9Button.setBackground(numColor);
        dot.setBackground(numColor);


//        dot.setSize(new Dimension(400, 400));


        panel.setBorder(BorderFactory.createEmptyBorder(50, 50, 40, 50));
        a0Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input.setText(input.getText() + "0");
            }
        });
        a1Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input.setText(input.getText() + "1");
            }
        });
        a2Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input.setText(input.getText() + "2");
            }
        });
        a3Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input.setText(input.getText() + "3");
            }
        });
        a4Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input.setText(input.getText() + "4");
            }
        });
        a5Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input.setText(input.getText() + "5");
            }
        });
        a6Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input.setText(input.getText() + "6");
            }
        });
        a7Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input.setText(input.getText() + "7");
            }
        });
        a8Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input.setText(input.getText() + "8");
            }
        });
        a9Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input.setText(input.getText() + "9");
            }

        });




        plus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input.setText(input.getText() + "+");
            }
        });

        minus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input.setText(input.getText() + "-");
            }
        });
        multiplication.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input.setText(input.getText() + "*");
            }
        });
        division.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input.setText(input.getText() + "/");
            }
        });
        cButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input.setText("");
            }
        });
        dot.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input.setText(input.getText() + ".");
            }
        });

        runButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int index = -1;
                if (input.getText().contains("+")) {
                    index = input.getText().indexOf('+');
                }
                else if(input.getText().contains("-")) {
                    index = input.getText().indexOf('-');
                }
                else if(input.getText().contains("*")) {
                    index = input.getText().indexOf('*');
                }
                else {
                    index = input.getText().indexOf('/');
                }

                if (index == -1) {
                    errorLabel.setBackground(Color.WHITE);
                    errorLabel.setText("Input second operand");
                }

                else {
                    String subString1 = input.getText().substring(0, index);
                    String subString2 = input.getText().substring(index + 1);
                    String result = calculate(Double.parseDouble(subString1), Double.parseDouble(subString2));
                    input.setText(result);
                    errorLabel.setText("");
                }

            }
        });


    }



    private String calculate(double x, double y) {
        if(input.getText().contains("+")) {
             return Double.toString(x + y);
        }
        else if(input.getText().contains("-")) {
            return Double.toString(x - y);
        }
        else if(input.getText().contains("*")) {
            return Double.toString(x * y);
        }
        else if(input.getText().contains("/")) {
            return Double.toString(x / y);
        }
        else {
            return null;
        }
    }

    public JPanel getPanel() {
        return this.panel;
    }


}

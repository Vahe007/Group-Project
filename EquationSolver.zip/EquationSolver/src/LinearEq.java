public class LinearEq {

}

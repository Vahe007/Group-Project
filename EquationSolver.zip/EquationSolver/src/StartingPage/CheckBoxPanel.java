package StartingPage;

import Calculator.CalculatorForm;
import Factorial.FactorialForm;
import LinearEquation.LinearEquationForm;
import QuadraticEquation.quadraticEquationForm;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CheckBoxPanel {
    private JCheckBox factorialCheckBox;
    private JCheckBox linearEquationCheckBox;
    private JCheckBox quadraticEquationCheckBox;
    private JButton selectButton;

    public JPanel panel;
    private JCheckBox calculatorCheckBox;
    private JFrame frame;
    private ButtonGroup checkBoxGroup;

    public CheckBoxPanel() {
        checkBoxGroup = new ButtonGroup();
        checkBoxGroup.add(factorialCheckBox);
        checkBoxGroup.add(linearEquationCheckBox);
        checkBoxGroup.add(quadraticEquationCheckBox);
        checkBoxGroup.add(calculatorCheckBox);


        panel.setBackground(Color.GRAY);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 70, 10));
        quadraticEquationCheckBox.setBackground(Color.GRAY);
        calculatorCheckBox.setBackground(Color.GRAY);
        linearEquationCheckBox.setBackground(Color.GRAY);
        factorialCheckBox.setBackground(Color.GRAY);
//        factorialCheckBox.setPreferredSize(new Dimension(250, 100));

        selectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (quadraticEquationCheckBox.isSelected()) {


                    frame = new JFrame("Quadratic Equations");
                    frame.add(new quadraticEquationForm().getPanel());


                    frame.pack();
                    frame.setVisible(true);

                }

                else if (linearEquationCheckBox.isSelected()) {


                    frame = new JFrame("Linear Equations");
                    frame.add(new LinearEquationForm().getPanel());

                    frame.pack();
                    frame.setVisible(true);

                }
                else if (calculatorCheckBox.isSelected()) {
                    frame = new JFrame("Calculator");
                    frame.add(new CalculatorForm().getPanel());

                    frame.pack();
                    frame.setVisible(true);
                }
                else if (factorialCheckBox.isSelected()) {
                    frame = new JFrame("Factorial");
                    frame.add(new FactorialForm().getPanel());

                    frame.pack();
                    frame.setVisible(true);
                }

            }
        });
    }


}

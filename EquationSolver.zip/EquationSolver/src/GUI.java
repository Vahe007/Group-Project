import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUI extends GeneralGUI implements ActionListener {
    private JFrame frame;
    private JButton button;
    private JLabel label;
    private JLabel labelResult;
    private JTextField tf;
    private String filedInput;
    private JLabel solved;


    private QuadraticEq quadraticEq;
    private LinearEq linearEq;
    private JFrame linearEqFrame;

    private GeneralGUI generalGUI;



    private JFrame quadraticEqFrame;


    public GUI() {
        super();


        labelResult = new JLabel();
        labelResult.setBounds(10, 20, 80, 25);


        frame = new JFrame();
        frame.setSize(650,650);

        frame.pack( );
        frame.setSize(150,100);





        /////////////////////
        generalGUI = new GeneralGUI();

        //taken from the parent class

        select.addActionListener(this);
        select.setText("select");

        generalGUI.panel.add(select);

        frame.add(generalGUI.panel);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setTitle("Equation Solver Program");

        frame.pack();

        frame.setVisible(true);
    }


    public String getEq() {
        return this.filedInput;
    }



    @Override
    public void actionPerformed(ActionEvent e) {
        if (generalGUI.quadratic.isSelected()) {

            quadraticEqFrame = new JFrame();


            quadraticEqFrame.setTitle("Quadratic Equation Solver");

            quadraticEqFrame.pack();

            quadraticEqFrame.setVisible(true);


            quadraticEqFrame.setSize(650,650);
            quadraticEq = new QuadraticEq();
            quadraticEqFrame.add(quadraticEq.getPanel());

        }
        else if (generalGUI.linear.isSelected()) {
            linearEqFrame = new JFrame();
            linearEqFrame.setTitle("Linear Equation Solver");
            linearEqFrame.pack();

            linearEqFrame.setVisible(true);


            linearEqFrame.setSize(650,650);

            linearEq = new LinearEq();
//            linearEqFrame.add(linearEq.getPanel());
        }
        else if (generalGUI.factorial.isSelected()) {

        }

    }

}

package Factorial;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigInteger;

public class FactorialForm implements ActionListener {
    private JLabel title;
    private JPanel panel;
    private JButton btn;
    private JTextField textField1;
    private JLabel resLabel;

    public FactorialForm() {
        panel.setBorder(BorderFactory.createEmptyBorder(50, 170, 70, 170));
        btn.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            int num = Integer.parseInt(textField1.getText());
            BigInteger factorial = BigInteger.ONE;

            int radix = 10;
            for (int i = num; i > 0; i--) {
                factorial = factorial.multiply(BigInteger.valueOf(i));
            }

            resLabel.setText(factorial.toString(radix));
        }
        catch (Exception err) {
            resLabel.setText("Input an integer");
        }
    }

    public JPanel getPanel() {
        return panel;
    }

}

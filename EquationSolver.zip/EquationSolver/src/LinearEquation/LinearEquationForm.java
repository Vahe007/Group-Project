package LinearEquation;
import QuadraticEquation.FormEquation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LinearEquationForm extends FormEquation {
    private JPanel panel;
    private JButton solve;
    private JLabel resultLabel;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JLabel title;
    private JLabel eqLabel;
    private String eqForm;


    private double result;

    private double a;
    private double b;
    private double c;

    public LinearEquationForm() {
        Color bgColor = new Color(242, 243, 242);
        Color btnColor = new Color(253, 193, 37);
        Color titleColor = new Color(3, 61, 252);

        solve.setBackground(btnColor);
        title.setForeground(titleColor);
        panel.setBorder(BorderFactory.createEmptyBorder(50, 170, 70, 170));
        panel.setBackground(bgColor);


        solve.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    a = Double.parseDouble(textField1.getText());
                    b = Double.parseDouble(textField2.getText());
                    c = Double.parseDouble(textField3.getText());
                    eqForm = getEquation(a, b, c, true);
                    eqLabel.setText(eqForm);
                    eqLabel.setForeground(titleColor);

                }
                catch (Exception err) {
                    resultLabel.setText("The coefficient and free values should be numbers");
                    return;
                }

                result = (c - b)/a;
                resultLabel.setText("Solution is " + result);


            }
        });
    }

    public JPanel getPanel() {
        return this.panel;
    }

}

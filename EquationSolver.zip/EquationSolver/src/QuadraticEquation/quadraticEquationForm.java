package QuadraticEquation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class quadraticEquationForm extends FormEquation {
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JLabel title;
    private JButton solve;
    private JLabel resultLabel;
    private JPanel panel;
    private JLabel coefficient1;
    private JLabel coefficient2;
    private JLabel free;
    private JLabel eqLabel;
    private String eqForm;



    public double x1;
    public double x2;
    public double d;

    double a;
    double b;
    double c;

    public quadraticEquationForm() {
        super();

        coefficient1.setForeground(Color.WHITE);
        coefficient2.setForeground(Color.WHITE);
        free.setForeground(Color.WHITE);
        title.setForeground(Color.WHITE);
        Color bgColor = new Color(40, 44, 52);
        Color btnColor = new Color(97, 218, 251);
        resultLabel.setForeground(btnColor);

        panel.setBackground(bgColor);
        solve.setBackground(btnColor);
        panel.setBorder(BorderFactory.createEmptyBorder(50, 170, 70, 170));
        solve.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    a = Double.parseDouble(textField1.getText());
                    b = Double.parseDouble(textField2.getText());
                    c = Double.parseDouble(textField3.getText());
                    eqForm = getEquation(a, b, c);  ///////////////////////////////////////////
                    eqLabel.setForeground(Color.WHITE);
                   eqLabel.setText(eqForm);
                }
                catch (Exception err) {
                    resultLabel.setText("Numbers should be entered as coefficients");
                    return;
                }


                //solution
                d = b * b - 4 * a * c;

                if (d > 0) {

                    x1 = (-b + Math.sqrt(d)) / (2 * a);
                    x2 = (-b - Math.sqrt(d)) / (2 * a);

                    resultLabel.setText("The solutions are " + x1 + " and " + x2);

                }
                else if (d == 0) {
                    x1 = x2 = -b / (2 * a);

                    resultLabel.setText("The only solution is " + x1);

                } else {
                    resultLabel.setText("There is no solution, since determinant is " + d);
                }

            }
        });


    }



    public JPanel getPanel() {
        return this.panel;
    }



}

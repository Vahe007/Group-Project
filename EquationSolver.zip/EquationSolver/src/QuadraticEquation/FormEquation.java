package QuadraticEquation;


public class FormEquation {
    private String result;
    public String getEquation(double a, double b, double c) {

//        System.out.println(b*(Math.signum(b)));

        result = a + "*X^2 +" + Math.signum(b)*b + "*X +" + Math.signum(c)*c;
        return result;

    }

    public String getEquation(double a, double b, double c, boolean flag) {
        result = a + "*X + " + b + " = " + Math.signum(c)*c;
        return result;

    }
}

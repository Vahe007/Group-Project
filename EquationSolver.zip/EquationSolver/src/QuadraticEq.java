import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class QuadraticEq implements ActionListener {
    JButton button;
    JLabel labelResult;
    JLabel equation;

    private JLabel label1;
    private JTextField field1;

    private JLabel label2;
    private JTextField field2;

    private JLabel label3;
    private JTextField field3;

    private JPanel panel;

    public QuadraticEq() {


        labelResult = new JLabel();
        labelResult.setBounds(10, 20, 80, 25);


        button = new JButton("Solve");
        button.setBounds(10, 80, 80, 25);




        panel = new JPanel();
        panel.setBorder(BorderFactory.createEmptyBorder(100, 50, 20, 50));


        label1 = new JLabel();
        label1.setText("Input the coefficient for x^2");

        label2 = new JLabel();
        label2.setText("Input the coefficient for x");

        label3 = new JLabel();
        label3.setText("Input the free value");


        this.field1 = new JTextField(20);
        this.field2 = new JTextField(20);
        this.field3 = new JTextField(20);



        this.field1.setBounds(100, 20, 165, 25);
        this.field2.setBounds(100, 20, 165, 25);
        this.field3.setBounds(100, 20, 165, 25);





        equation = new JLabel();

        panel.add(label1);
        panel.add(this.field1);
        panel.add(label2);
        panel.add(this.field2);
        panel.add(label3);
        panel.add(this.field3);
        panel.add(button);
        panel.add(equation);
        panel.add(labelResult);
        button.addActionListener(this);






    }



    public JPanel getPanel() {
        return panel;
    }



    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("worked");

        double a = Double.parseDouble(field1.getText());
        double b = Double.parseDouble(field2.getText());
        double c = Double.parseDouble(field3.getText());

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        equation.setText("The equation is: " + a + " * x^2 " + " + " + b + " * x " + " + " + c );

        QuadraticEqSolution obj = new QuadraticEqSolution(a, b, c);
        double[] result = obj.calculate();

        if (result == null) {
            labelResult.setText("System has no solution as determinant equals to " + obj.getDeterminant());
            return;
        }


        labelResult.setText("The solutions are " + result[0] + " and " + result[1]);
    }


    public JLabel getResults() {
        return labelResult;
    }
}
